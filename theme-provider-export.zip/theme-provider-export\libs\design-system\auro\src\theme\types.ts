export type Brand = 'cfs';
export type Theme = 'light' | 'dark';

export interface ThemeContextValue {
  brand: Brand;
  theme: Theme;
  setBrand: (brand: Brand) => void;
  setTheme: (theme: Theme) => void;
}
