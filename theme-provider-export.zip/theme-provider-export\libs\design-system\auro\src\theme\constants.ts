import type { Brand, Theme } from './types';

export const DEFAULT_BRAND: Brand = 'cfs';
export const DEFAULT_THEME: Theme = 'light';
