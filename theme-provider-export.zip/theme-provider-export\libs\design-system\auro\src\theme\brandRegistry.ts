import type { Brand } from './types';

/**
 * Each entry is a static import() so Vite can code-split per brand at build time.
 * To add a new brand: add one line here and extend the Brand type in types.ts.
 */
export const brandRegistry: Record<Brand, () => Promise<unknown>> = {
  cfs: () => import('../tokens/web/cfs/index.css'),
};
