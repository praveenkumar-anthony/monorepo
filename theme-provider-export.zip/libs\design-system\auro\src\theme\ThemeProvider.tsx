import React, {
  createContext,
  useCallback,
  useEffect,
  useState,
} from 'react';
import { DEFAULT_BRAND, DEFAULT_THEME, BRAND_LINK_ID } from './constants';
import type { Brand, Theme, ThemeContextValue } from './types';

export const ThemeContext = createContext<ThemeContextValue | null>(null);

interface ThemeProviderProps {
  initialBrand?: Brand;
  initialTheme?: Theme;
  children: React.ReactNode;
}

export function ThemeProvider({
  initialBrand,
  initialTheme,
  children,
}: ThemeProviderProps) {
  const [brand, setBrandState] = useState<Brand>(
    initialBrand ?? DEFAULT_BRAND
  );
  const [theme, setThemeState] = useState<Theme>(
    initialTheme ?? DEFAULT_THEME
  );

  // Storybook: sync toolbar global changes into local state
  useEffect(() => {
    if (initialBrand) setBrandState(initialBrand);
  }, [initialBrand]);

  useEffect(() => {
    if (initialTheme) setThemeState(initialTheme);
  }, [initialTheme]);

  // Find or create one <link> tag, update href to active brand.
  // Served from public/tokens/ as a static asset — outside Vite's
  // CSS pipeline, no HMR conflict with Tailwind.
  // On brand switch: same tag, href updated — clean swap, no accumulation.
  useEffect(() => {
    let link = document.getElementById(BRAND_LINK_ID) as HTMLLinkElement | null;

    if (!link) {
      link = document.createElement('link');
      link.id = BRAND_LINK_ID;
      link.rel = 'stylesheet';
      document.head.appendChild(link);
    }

    link.href = `/tokens/${brand}/index.css`;
  }, [brand]);

  // Toggles data-theme for token CSS selectors ([data-theme="dark"])
  // and .dark class for Tailwind dark: utilities — both in sync.
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  const setBrand = useCallback((b: Brand) => setBrandState(b), []);
  const setTheme = useCallback((t: Theme) => setThemeState(t), []);

  return (
    <ThemeContext.Provider value={{ brand, theme, setBrand, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}
