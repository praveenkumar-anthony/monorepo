# Token files go here

Copy the contents of `auro-tokens-output/web/cfs/` from the figma-tokens-automation repo into this folder.

Expected files:
- index.css
- color.css
- spacing.css
- typography.css
- motion.css
- layout.css
- z_index.css
- components.css
