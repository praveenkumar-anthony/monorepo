import type { StorybookConfig } from '@storybook/react-vite';

const config: StorybookConfig = {
  // ... your existing config

  // Serve public/tokens/ as static assets in Storybook canvas
  // so /tokens/{brand}/index.css resolves correctly.
  staticDirs: ['../public'],
};

export default config;
