import { ThemeProvider } from '@<org>/design-system-auro';
import type { Brand } from '@<org>/design-system-auro';

// Replace @<org>/design-system-auro with your actual tsconfig.base.json path alias.

interface AppProps {
  brand: Brand;
}

export default function App({ brand }: AppProps) {
  return (
    <ThemeProvider initialBrand={brand} initialTheme="light">
      {/* your existing routes here */}
    </ThemeProvider>
  );
}
