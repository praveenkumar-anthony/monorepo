import React from 'react';
import type { Preview, Decorator } from '@storybook/react';
import { HeroUIProvider } from '@heroui/react';
import { ThemeProvider } from '@<org>/design-system-auro';
import type { Brand, Theme } from '@<org>/design-system-auro';

// Replace @<org>/design-system-auro with your actual tsconfig.base.json path alias.
// Add new brands to the toolbar items array as they are introduced.

const withThemeProvider: Decorator = (Story, context) => {
  const brand = context.globals['brand'] as Brand;
  const theme = context.globals['theme'] as Theme;

  return (
    <ThemeProvider initialBrand={brand} initialTheme={theme}>
      <HeroUIProvider>
        <Story />
      </HeroUIProvider>
    </ThemeProvider>
  );
};

const preview: Preview = {
  globalTypes: {
    brand: {
      name: 'Brand',
      defaultValue: 'cfs',
      toolbar: {
        icon: 'paintbrush',
        items: ['cfs'],
        dynamicTitle: true,
      },
    },
    theme: {
      name: 'Theme',
      defaultValue: 'light',
      toolbar: {
        icon: 'circlehollow',
        items: ['light', 'dark'],
        dynamicTitle: true,
      },
    },
  },
  decorators: [withThemeProvider],
};

export default preview;
