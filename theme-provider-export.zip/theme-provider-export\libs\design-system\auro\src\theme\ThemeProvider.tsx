import React, {
  createContext,
  useCallback,
  useEffect,
  useState,
} from 'react';
import { DEFAULT_BRAND, DEFAULT_THEME } from './constants';
import { brandRegistry } from './brandRegistry';
import type { Brand, Theme, ThemeContextValue } from './types';

export const ThemeContext = createContext<ThemeContextValue | null>(null);

interface ThemeProviderProps {
  initialBrand?: Brand;
  initialTheme?: Theme;
  children: React.ReactNode;
}

export function ThemeProvider({
  initialBrand,
  initialTheme,
  children,
}: ThemeProviderProps) {
  const [brand, setBrandState] = useState<Brand>(
    initialBrand ?? DEFAULT_BRAND
  );
  const [theme, setThemeState] = useState<Theme>(
    initialTheme ?? DEFAULT_THEME
  );

  // Storybook: sync toolbar global changes into local state
  useEffect(() => {
    if (initialBrand) setBrandState(initialBrand);
  }, [initialBrand]);

  useEffect(() => {
    if (initialTheme) setThemeState(initialTheme);
  }, [initialTheme]);

  // Load brand CSS chunk — Vite injects it as <style> in <head>
  useEffect(() => {
    brandRegistry[brand]();
  }, [brand]);

  // Light/dark — instant attribute flip, no async needed
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const setBrand = useCallback((b: Brand) => setBrandState(b), []);
  const setTheme = useCallback((t: Theme) => setThemeState(t), []);

  return (
    <ThemeContext.Provider value={{ brand, theme, setBrand, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}
