# Token files go here

Copy the contents of `auro-tokens-output/web/cfs/` into this folder.

Expected files:
- index.css
- color.css
- spacing.css
- typography.css
- motion.css
- layout.css
- z_index.css
- components.css

Add a new brand folder here as brands are introduced e.g. public/tokens/brandB/
