// Add these exports to your existing libs/design-system/auro/src/index.ts barrel

export { ThemeProvider } from './theme/ThemeProvider';
export { useTheme } from './theme/useTheme';
export type { Brand, Theme, ThemeContextValue } from './theme/types';
export { DEFAULT_BRAND, DEFAULT_THEME } from './theme/constants';
