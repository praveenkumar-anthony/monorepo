import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { DEFAULT_BRAND } from '@<org>/design-system-auro';
import type { Brand } from '@<org>/design-system-auro';
import App from './app';

// Replace @<org>/design-system-auro with your actual tsconfig.base.json path alias.
// Replace window.uiConfig with the actual property set by uiconfig.js.

declare global {
  interface Window {
    uiConfig?: { brand?: string };
  }
}

const brand = (window.uiConfig?.brand as Brand) ?? DEFAULT_BRAND;

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App brand={brand} />
  </StrictMode>
);
